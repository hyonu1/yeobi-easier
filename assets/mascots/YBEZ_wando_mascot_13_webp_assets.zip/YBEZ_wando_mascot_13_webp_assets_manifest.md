# YBEZ 완도 마스코트 13장 WebP 자산화 패키지

## 적용 대상

- 경로: `assets/mascots/`
- 형식: 512×512 WebP
- 작업 범위: 완도 팝업 마스코트 이미지 자산 13장
- HTML / 계산 로직 / JSON 로직 수정 없음

## 파일 목록

| 순서 | 지역 | 파일명 | 원본 생성 파일 |
|---:|---|---|---|
| 1 | 완도 | `assets/mascots/jg_wd_wando.webp` | `a_brightly_lit_highly_polished_cartoon_like_chib_1_batch_1.png` |
| 2 | 군외 | `assets/mascots/jg_wd_gunoe.webp` | `a_bright_cheerful_highly_detailed_cartoon_illus_2_batch_2.png` |
| 3 | 신지 | `assets/mascots/jg_wd_sinji.webp` | `a_bright_cheerful_cartoon_illustration_scene_a_c_3_batch_3.png` |
| 4 | 고금 | `assets/mascots/jg_wd_gogeum.webp` | `a_bright_cheerful_highly_detailed_cartoon_illust_4_batch_4.png` |
| 5 | 약산 | `assets/mascots/jg_wd_yaksan.webp` | `a_bright_cute_painterly_cartoon_illustration_of_1_batch_1.png` |
| 6 | 청산 | `assets/mascots/jg_wd_cheongsan.webp` | `a_bright_cheerful_storybook_style_illustration_2_batch_2.png` |
| 7 | 노화 | `assets/mascots/jg_wd_nohwa.webp` | `a_bright_warm_stylized_cartoon_illustration_scen_3_batch_3.png` |
| 8 | 보길 | `assets/mascots/jg_wd_bogil.webp` | `bright_warm_cute_cartoon_illustration_scene_in_a_4_batch_4.png` |
| 9 | 소안 | `assets/mascots/jg_wd_soan.webp` | `a_bright_cheerful_cartoon_illustration_scene_in_a_1_batch_1.png` |
| 10 | 금일 | `assets/mascots/jg_wd_geumil.webp` | `a_cute_bright_storybook_cartoon_illustration_of_2_batch_2.png` |
| 11 | 생일 | `assets/mascots/jg_wd_saengil.webp` | `a_bright_cute_storybook_style_illustration_of_a_1.png` |
| 12 | 금당 | `assets/mascots/jg_wd_geumdang.webp` | `a_bright_high_detail_pastel_cartoon_anime_style_2_batch_2.png` |
| 13 | 여서도 | `assets/mascots/jg_wd_yeoseodo.webp` | `a_bright_cheerful_storybook_animated_illustratio_1.png` |

## 최종 팝업 순서

```text
완도 → 군외 → 신지 → 고금 → 약산 → 청산 → 노화 → 보길 → 소안 → 금일 → 생일 → 금당 → 여서도
```

## 적용 방법

ZIP 안의 `assets/mascots/*.webp` 파일을 GitHub 저장소의 같은 경로에 업로드 또는 덮어쓰기한다.

## 주의

- 기존 파일명 유지.
- `jg_wd_yeoseodo.webp`는 신규 추가 파일.
- `mascot_map.json`의 이미지 경로는 `assets/mascots/<파일명>.webp`와 일치해야 함.
- 요금 계산, 권역 산정, 신안/완도 특수지역 로직은 건드리지 않음.